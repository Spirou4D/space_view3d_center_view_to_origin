import bpy


bl_info = {
		"name": "Center view3D to Origin",
		"author": "Aldrik, Spirou4D",
		"version": (0,2),
		"blender": (2, 67, 0),
		"description": "Move the view to the World origin",
		"warning": "crtl + shift + Numpad .",
		"location": "View3D > Tool Shelf",
		"wiki_url": "",
		"tracker_url": "",
		"category": "3D View"}

# ------ operator ------
class VIEW3D_OP_Origin_All_View (bpy.types.Operator):
	bl_idname = 'view3d.origin_all_view'
	bl_options = {'REGISTER', 'UNDO'}
	bl_label = "Center view to origin"

	def invoke(self, context, event):
			v3d = context.space_data
			if v3d.type == 'VIEW_3D':
				rv3d = v3d.region_3d
				current_cloc = v3d.cursor_location.xyz
				v3d.cursor_location = (0, 0, 0)
				bpy.ops.view3d.view_center_cursor()
				v3d.cursor_location = current_cloc
			return {'FINISHED'}

# ------ panel ------
class VIEW3D_OT_Origin_All_View(bpy.types.Panel):
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'TOOLS'
	bl_category = 'Basic'
	bl_label = "Origin'all View"

	def draw(self, context):
		layout = self.layout
		layout.operator("view3d.origin_all_view", text="Center view to origin")


# ------ register ------
def register():
	bpy.utils.register_module(__name__)

	km_list = ['Object Mode', 'Mesh']
	for i in km_list:
		sm = bpy.context.window_manager
		km = sm.keyconfigs.default.keymaps[i]
		kmi = km.keymap_items.new('wm.call_menu', 'NUMPAD_PERIOD', 'PRESS', ctrl=True, shift=True )
		kmi.properties.name = "VIEW3D_OT_Origin_All_View"

# ------ unregister ------
def unregister():
	bpy.utils.unregister_module(__name__)

	km_list = ['Object Mode', 'Mesh']
	for i in km_list:
		sm = bpy.context.window_manager
		km = sm.keyconfigs.default.keymaps[i]
		for kmi in (kmi for kmi in km.keymap_items if (kmi.idname == "wm.call_menu" and kmi.properties.name == "VIEW3D_OT_Origin_All_View")):
			km.keymap_items.remove(kmi)

# ------ ------
if __name__ == '__main__':
	register()
